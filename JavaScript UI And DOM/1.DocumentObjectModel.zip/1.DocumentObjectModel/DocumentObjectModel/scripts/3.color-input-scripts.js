﻿function changeBackgroundColor() {
    var colorInput = document.getElementById('color-input').value;
    console.log(colorInput);
    document.bgColor = colorInput;
}