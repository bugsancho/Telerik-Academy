﻿function getTextInput() {
    var inputText = document.getElementById('text-input').value;

    console.log(inputText);
}