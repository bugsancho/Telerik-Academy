﻿function Solve(input) {
    var N = parseInt(input[0]),
        counter = 1,
        numbers = [],
        i;

    for (i = 0; i < N; i++) {
        numbers[i] = parseInt(input[i + 1]);
    }

    for (i = 0; i < input.length - 2; i++) {
        if (numbers[i] > numbers[i + 1]) {
            counter++;
        }
    }

    return counter;
}
