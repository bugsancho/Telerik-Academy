﻿interface IFigure
{
    double CalcSurface();

    double CalcPerimeter();
}