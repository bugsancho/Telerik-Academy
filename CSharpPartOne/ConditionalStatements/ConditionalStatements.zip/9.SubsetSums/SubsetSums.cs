﻿using System;
    class SubsetSums
    {
        static void Main(string[] args)
        {
            int[] numbers = new int[5];
            int counter = 0;
            for (int i = 0; i < 5; i++)
            {
                Console.WriteLine("Please enter a number: ");
                numbers[i] = int.Parse(Console.ReadLine());
            }
            for (int i = 0; i < 5; i++)
            {
                int sum = 0;
                for (int j = 0; j < 5; j++)
                {
                    sum += ((i >> j) & 1) * numbers[j];
                }
                if (sum == 0)
                {
                    counter++;
                }
            }
            Console.WriteLine("The number of subsets equal to zero are: {0}", counter);
        }
    }

