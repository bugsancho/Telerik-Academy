﻿using System;
class LeapYearCheck
{ //Write a program that reads a year from the console and checks whether it is a leap. Use DateTime.

    static void Main()
    {
        Console.WriteLine("Please enter a year: ");
        int date =int.Parse(Console.ReadLine());
        if (DateTime.IsLeapYear(date))
        {
            Console.WriteLine("The year {0} is a leap year!", date);
        }
        else
        {
            Console.WriteLine("The year {0} is not a leap year!", date);
        }
    }
}