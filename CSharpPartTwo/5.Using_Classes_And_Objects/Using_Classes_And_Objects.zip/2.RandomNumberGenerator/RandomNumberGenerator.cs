﻿using System;
class RandomNumberGenerator
{
    //Write a program that generates and prints to the console 10 random values in the range [100, 200].
    private static Random rand = new Random();
    static void Main()
    {
        Console.WriteLine("Here are 10 random numbers: ");
        for (int i = 0; i < 10; i++)
        {
            Console.Write(rand.Next(101,201) + ", ");
        }
        Console.WriteLine();
    }
}
