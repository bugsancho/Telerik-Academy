﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Threading;
class MathExpression
{
    //* Write a program that calculates the value of given arithmetical expression. The expression can contain the following elements only:
    //Real numbers, e.g. 5, 18.33, 3.14159, 12.6
    //Arithmetic operators: +, -, *, / (standard priorities)
    //Mathematical functions: ln(x), sqrt(x), pow(x,y)
    //Brackets (for changing the default priorities)
    private static string buffer = "";
    private static bool isNumber = false;
    private static Queue<string> expression = new Queue<string>();
    private static Stack<string> operators = new Stack<string>();

    static void Main()
    {
        Thread.CurrentThread.CurrentCulture = CultureInfo.InvariantCulture;
        Console.WriteLine("This is a simple calculator that calculates mathematical expressions using:");
        Console.WriteLine("Arithmetic operators: +, -, *, /");
        Console.WriteLine("Mathematical functions: ln(x), sqrt(x), pow(x,y).");
        Console.WriteLine("Brackets (for changing the default priorities).");
        Console.WriteLine("Please enter your mathematical expression:");
        string input = Console.ReadLine();
        input = input.ToLowerInvariant();
        input = input.Replace(" ", "");
        expression = ConvertToPostfix(input);
        double result = CalculateExpression(expression);
        Console.Write("The result of the expression is: ");
        Console.WriteLine(result);
    }

    private static double CalculateExpression(Queue<string> expression)
    {
        //This method uses the already parsed input data and applies the reversed polish notation algorithm to calculate the result.

        double result = 0;
        Stack<string> numbers = new Stack<string>();
        int loopLength = expression.Count;
        double firstNumber = 0;
        double secondNumber = 0;
        double number = 0;

        //We go over all the elements in the queue and if we reach a number, its pushed into the stack.
        //And if an operator(function) is reached it pops the last 1 or 2 elements,
        // depending of the operator and push into the stack the result of the mathematical operation.
        for (int token = 0; token < loopLength; token++)
        {
            if (double.TryParse(expression.Peek(), out number))
            {
                numbers.Push(expression.Dequeue().ToString());
            }
            else
            {
                switch (expression.Peek())
                {
                    case "+":
                        numbers.Push((double.Parse(numbers.Pop()) + double.Parse(numbers.Pop())).ToString()); break;
                    case "-": 
                        firstNumber = double.Parse(numbers.Pop()); secondNumber = double.Parse(numbers.Pop());
                        numbers.Push((secondNumber - firstNumber).ToString()); break;
                    case "*":
                        numbers.Push((double.Parse(numbers.Pop()) * double.Parse(numbers.Pop())).ToString()); break;
                    case "/":
                        firstNumber = double.Parse(numbers.Pop()); secondNumber = double.Parse(numbers.Pop());
                        numbers.Push((secondNumber / firstNumber).ToString()); break;
                    case "pow":
                        firstNumber = double.Parse(numbers.Pop()); secondNumber = double.Parse(numbers.Pop());
                        numbers.Push((Math.Pow(secondNumber, firstNumber)).ToString()); break;
                    case "ln":
                        firstNumber = double.Parse(numbers.Pop());
                        numbers.Push((Math.Log(firstNumber)).ToString()); break;
                    case "sqrt":
                        firstNumber = double.Parse(numbers.Pop());
                        numbers.Push((Math.Sqrt(firstNumber)).ToString()); break;
                    default: 
                        throw new ArgumentException(message: "Invalid input!");
                }
                expression.Dequeue();
            }
        }
        //After going through all the elements of the queue we check if there are any more left elements in the queue and if there is more than one element in the stack.
        //If there are no elements in the queue and only one in the stack - that is the result, otherwise something's gone wrong.
        if (expression.Count == 0 && numbers.Count == 1)
        {
            result = double.Parse(numbers.Pop());
        }
        else
        {
            throw new SystemException();
        }

        return result;
    }

    private static Queue<string> ConvertToPostfix(string input)
    {
        //This method reads all the tokens and applies the shunting yard algotihm on them to convert the expression to postfix notation.
        for (int i = 0; i < input.Length; i++)
        {
            ReadChar(input, i);
        }
        //after reading all the tokens we pop the remaining operators off the stack
        //and check whether there is a parentesis in the stack, which would mean the input is not correct.
        while (operators.Count != 0)
        {
            if (operators.Peek() == "(" || operators.Peek() == ")")
            {
                throw new ArgumentException(message: "Wrong input");
            }
            expression.Enqueue(operators.Pop());
        }

        return expression;
    }

    public static int Precedence(string mathOperator)
    {
        //Method that determines the mathematical precedence of the given operator.
        if (mathOperator == "+" || mathOperator == "-")
        {
            return 1;
        }
        else
        {
            return 2;
        }
    }

    private static void ReadChar(string input, int i)
    {
        //This method reads a character(token) and follows the logic of the shunting yard algorithm.

        //First we check whether the token is a number and if so we put it digit by digit into a buffer.
        if ((input[i] <= '9' && input[i] >= '0') || (input[i] == '.' && isNumber))
        {
            buffer = buffer + input[i];
            if (i == input.Length - 1)
            {
                expression.Enqueue(buffer);
            }
            isNumber = true;
        }
        //If the token isnt part of a number we go over all the possible cases:
        else
        {
            //First we check if there's a number in the buffer and we add it into the expression queue.
            if (isNumber)
            {
                expression.Enqueue(buffer);
                buffer = "";
            }
            isNumber = false;
            switch (input[i])
            {
                //After that we check if the token is an operator or part of such.
                case '+':
                    //If we find an operator we pop from the stack all the operators with equal or higher precedence (using the simple method introduced above) 
                    // and then push the operator itself into the stack.(This applies for all the operators below)
                    while (operators.Count != 0)
                    {
                        if (operators.Peek() != "(")
                        {
                            expression.Enqueue(operators.Pop());
                        }
                        else
                        {
                            break;
                        }
                    }
                    operators.Push(input[i].ToString()); break;
                case '-':
                    //If the token is '-' we check whether it stands for the negative sign of a number or the mathematical operator.
                    //We do this by checking the previous token(character).
                    if (i == 0 || input[i - 1] == '(' || input[i - 1] == ',')
                    {
                        buffer = "-"; break;
                    }
                    else
                    {
                        while (operators.Count != 0)
                        {
                            if (operators.Peek() != "(")
                            {
                                expression.Enqueue(operators.Pop());
                            }
                            else
                            {
                                break;
                            }
                        }
                    }
                    operators.Push(input[i].ToString()); break;
                case '*':
                    while ((operators.Count != 0) && Precedence(operators.Peek()) == 2)
                    {
                        if (operators.Peek() != "(")
                        {
                            expression.Enqueue(operators.Pop());
                        }
                        else
                        {
                            break;
                        }
                    }
                    operators.Push(input[i].ToString()); break;
                case '/':
                    while ((operators.Count != 0) && Precedence(operators.Peek()) == 2)
                    {
                        if (operators.Peek() != "(")
                        {
                            expression.Enqueue(operators.Pop());
                        }
                        else
                        {
                            break;
                        }
                    }
                    operators.Push(input[i].ToString()); break;
                case '(': //If the token is left perentesis we simply put it into the stack.
                    operators.Push(input[i].ToString()); break;
                case ')': //And if we reach a right parentesis we pop operators from the stack until a left parentesis is reached.
                    while (operators.Count != 0)
                    {
                        if (operators.Peek() == "(")
                        {
                            operators.Pop();
                        }
                        else
                        {
                            expression.Enqueue(operators.Pop());
                        }
                    }
                    break;
                    //Then if the token is part of a function we read it letter by letter and if at the end we dont get the wording for a function,
                    // an exception is thrown, otherwise we push the function into the expression queue.
                case 'p': buffer += 'p'; break;
                case 'o': buffer += 'o'; break;
                case 'w': buffer += 'w'; 
                    if (buffer == "pow")
                    {
                        operators.Push(buffer);
                        buffer = "";
                    }
                    else
                    {
                        throw new ArgumentException(message: "Invalid input!");
                    }
                    break;
                case 'l': buffer += 'l'; break;
                case 'n': buffer += 'n'; 
                    if (buffer == "ln")
                    {
                        operators.Push(buffer);
                        buffer = "";
                    }
                    else
                    {
                        throw new ArgumentException(message: "Invalid input!");
                    } break;
                case 's': buffer += 's'; break;
                case 'q': buffer += 'q'; break;
                case 'r': buffer += 'r'; break;
                case 't': buffer += 't'; 
                    if (buffer == "sqrt")
                    {
                        operators.Push(buffer);
                        buffer = "";
                    }
                    else
                    {
                        throw new Exception();
                    }
                    break;
                case ',':
                    //If we come across a comma, we pop elements until a left parentesis is reached(that's because a comma should only appear in a function).
                    while (operators.Pop() != "(")
                    {
                        if (operators.Count == 0)
                        {
                            throw new ArgumentException();
                        }
                        operators.Pop();
                    }
                    break;
                default: throw new ArgumentException(message: "Invalid input!");
            }
        }
    }
}
