﻿using System;
    class TriangleAreaCalculation
    {
        //Write methods that calculate the surface of a triangle by given:
        //Side and an altitude to it; Three sides; Two sides and an angle between them. Use System.Math.

        static void Main()
        {
            Console.WriteLine("This program calculates the area of a triangle.");
            Console.WriteLine("Please specify what input data you are about to enter.");
            Console.WriteLine("For side and height to it - enter 1!");
            Console.WriteLine("For three sides - enter 2!");
            Console.WriteLine("For two sides and their included angle - enter 3!");
            byte choice = byte.Parse(Console.ReadLine());
            double area = 0;
            switch (choice)
            {
                case 1: area = SideAndHeightCalc(); break;
                case 2: area = ThreeSidesCalc(); break;
                case 3: area = TwoSidesAndAngleCalc(); break;
                default: Console.WriteLine("Incorrect input!");
                    break;
            }
            Console.WriteLine("The area of the triangle is: {0:0.00} !", area);
        }

        private static double TwoSidesAndAngleCalc()
        {
            Console.WriteLine("Now enter a value for the angle in radians:");
            double angle = double.Parse(Console.ReadLine());
            Console.WriteLine("Now enter a value for first side: ");
            double firstSide = double.Parse(Console.ReadLine());
            Console.WriteLine("And now a value for the other side: ");
            double secondSide = double.Parse(Console.ReadLine());
            double area = (firstSide * secondSide) / 2 * Math.Sin(angle);
            return area;
        }
        
        private static double ThreeSidesCalc()
        {
            Console.WriteLine("Now enter value for the first side:");
            double firstSide = double.Parse(Console.ReadLine());
            Console.WriteLine("Now enter value for the second side:");
            double secondSide = double.Parse(Console.ReadLine());
            Console.WriteLine("And now enter value for the third side:");
            double thirdSide = double.Parse(Console.ReadLine());
            double semiPerimeter = (firstSide + secondSide + thirdSide) /2.0;
            double area = Math.Sqrt(semiPerimeter*(semiPerimeter-firstSide)*(semiPerimeter-secondSide)*(semiPerimeter-thirdSide));
            return area;
            
        }

        private static double SideAndHeightCalc()
        {
            Console.WriteLine("Now enter a value for the side of the triangle: ");
            double side = double.Parse(Console.ReadLine());
            Console.WriteLine("And now a value for the height: ");
            double height = double.Parse(Console.ReadLine());
            double area = (side*height)/2.0;
            return area;
        }
    }
