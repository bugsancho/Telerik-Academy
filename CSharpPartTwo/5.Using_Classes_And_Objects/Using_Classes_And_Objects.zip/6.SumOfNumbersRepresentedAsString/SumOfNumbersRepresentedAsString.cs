﻿using System;
using System.Collections.Generic;
class SumOfNumbersRepresentedAsString
{
    //You are given a sequence of positive integer values written into a string, separated by spaces. 
    //Write a function that reads these values from given string and calculates their sum. Example:
    //string = "43 68 9 23 318"  result = 461

    static void Main()
    {
        Console.WriteLine("Please enter a sequence of integers on the next line, separated by white spaces");
        string input = Console.ReadLine();
        string[] numbersStr = input.Split();
        int[] numbers = new int[numbersStr.Length];
        for (int i = 0; i < numbersStr.Length; i++)
        {
            numbers[i] = int.Parse(numbersStr[i]);
        }
        int sum = 0;
        foreach (var number in numbers)
        {
            sum += number;
        }
        Console.WriteLine("The sum of the given numbers is: {0}!", sum);
    }
}
