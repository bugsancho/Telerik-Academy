﻿using System;
using System.Collections.Generic;
class CalculateWorkdays
{
    //Write a method that calculates the number of workdays between today and given date, passed as parameter.
    //Consider that workdays are all days from Monday to Friday except a fixed list of public holidays specified preliminary as array.
    public static List<DateTime> holidays = new List<DateTime>();

    static void Main()
    {
        Console.WriteLine("Please enter a date in the format: DD.MM.YYYY");
        DateTime input = DateTime.Parse(Console.ReadLine());
        DateTime today = DateTime.Today;
        AddHolidays();
        int workdays = GetWorkDays(input, today);
        Console.Write("The workdays in the period given are: ");
        Console.WriteLine(workdays);
    }
    private static void AddHolidays()
    {
        holidays.Add(new DateTime(2013, 1, 1));
        holidays.Add(new DateTime(2013, 3, 3));
        holidays.Add(new DateTime(2013, 5, 1));
        holidays.Add(new DateTime(2013, 5, 2));
        holidays.Add(new DateTime(2013, 5, 3));
        holidays.Add(new DateTime(2013, 5, 4));
        holidays.Add(new DateTime(2013, 5, 5));
        holidays.Add(new DateTime(2013, 5, 6));
        holidays.Add(new DateTime(2013, 5, 24));
        holidays.Add(new DateTime(2013, 9, 6));
        holidays.Add(new DateTime(2013, 9, 22));
        holidays.Add(new DateTime(2013, 12, 24));
        holidays.Add(new DateTime(2013, 12, 25));
        holidays.Add(new DateTime(2013, 12, 26));
        holidays.Add(new DateTime(2013, 12, 31));
    }
    private static int GetWorkDays(DateTime input, DateTime today)
    {
        int dayCounter = 0;
        if (input.CompareTo(today) <0)
        {
            today = input;
            input = DateTime.Today;
        }
        while (today.CompareTo(input) < 0)
        {
            if (today.DayOfWeek != DayOfWeek.Saturday && today.DayOfWeek != DayOfWeek.Sunday && !holidays.Contains(today))
            {
                dayCounter++;
            }
            today= today.AddDays(1);
        }
        return dayCounter;
    }
}